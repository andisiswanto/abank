/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';
	/*KCFINDER
	 config.filebrowserBrowseUrl = 'kcfinder30/browse.php?type=files';
   	config.filebrowserImageBrowseUrl = 'kcfinder30/browse.php?type=images';
   	config.filebrowserFlashBrowseUrl = 'kcfinder30/browse.php?type=flash';
   	config.filebrowserUploadUrl = 'kcfinder30/upload.php?type=files';
   	config.filebrowserImageUploadUrl = 'kcfinder30/upload.php?type=images';
   	config.filebrowserFlashUploadUrl = 'kcfinder30/upload.php?type=flash';
	*/
};
